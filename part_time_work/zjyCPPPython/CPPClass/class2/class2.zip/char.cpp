#include <iostream>
using namespace std;

int main()
{
    char c1 = 'C';
    char c2 = 80; //十进制的整数
    char c3 = 0x50; //十六进制的整数
    cout << c1 << ":" << c2 << ":"<< c3 << endl;

    
    return 0;
}

