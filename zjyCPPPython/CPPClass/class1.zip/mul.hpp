#pragma once

// 声明 mul 函数：告诉电脑编译器，mul 函数在哪里定义
int mul(int a, int b);
