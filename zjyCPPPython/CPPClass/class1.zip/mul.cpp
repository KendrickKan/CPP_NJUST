#include "mul.hpp"

// 定义 mul 函数具体实现
int mul(int a, int b)
{
    int c = a * b;
    return c;
}
